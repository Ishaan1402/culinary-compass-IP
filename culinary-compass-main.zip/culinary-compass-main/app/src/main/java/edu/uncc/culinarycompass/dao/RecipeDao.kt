package edu.uncc.culinarycompass.dao

interface RecipeDao {
}