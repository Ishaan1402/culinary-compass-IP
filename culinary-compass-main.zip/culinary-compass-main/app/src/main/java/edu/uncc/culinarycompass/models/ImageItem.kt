package edu.uncc.culinarycompass.models

data class ImageItem (
    val id: String,
    val url : String
)

