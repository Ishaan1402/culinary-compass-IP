package edu.uncc.culinarycompass.database

class RecipeDatabase {
}